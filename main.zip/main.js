document.addEventListener('DOMContentLoaded', () => {
    // Register ScrollTrigger plugin from GSAP
    gsap.registerPlugin(ScrollTrigger);

    // ==========================
    // Reusable Scroll-Based Animation Setup
    // ==========================
    function pinAndAnimate({ trigger, endTrigger, pin, animations, markers = false, headerOffset = 0 }) {
        const end = `top top+=${headerOffset}`;
        const tl = gsap.timeline({
            scrollTrigger: {
                trigger,
                start: `top top+=${headerOffset}`,
                endTrigger,
                end,
                scrub: 1.5, // Increased scrub for smoother, slower movement
                pin,
                pinSpacing: false,
                markers: markers, // for debugging
                invalidateOnRefresh: true, // ensures recalculation on resize
            },
        });

        animations.forEach(({ target, vars, position = 0 }) => {
            tl.to(target, vars, position);
        });
    }

    // ==========================
    // ScrollTrigger Configurations
    // ==========================
    function setupScrollAnimations() {
        const headerOffset = 0; // Header is not fixed in this layout

        ScrollTrigger.matchMedia({
            // Desktop scroll animations
            "(min-width: 769px)": function () {
                // 1. Bottle animates on scroll from hero to section 2 (rain video)
                pinAndAnimate({
                    trigger: ".hero",
                    endTrigger: ".section-intro",
                    pin: ".hero-bottle-wrapper",
                    animations: [
                        // Rotate upright and fall towards the rock
                        { target: ".hero-bottle", vars: { rotate: 0, scale: 1, y: "10%", duration: 0.7, ease: "power1.in" }, position: 0 },
                        // Hit the rock and bounce up significantly
                        { target: ".hero-bottle", vars: { y: "-5%", duration: 0.15, ease: "power1.out" }, position: 0.7 },
                        // Fall back down and settle on the rock
                        { target: ".hero-bottle", vars: { y: "10%", duration: 0.15, ease: "power1.in" }, position: 0.85 }
                    ],
                    headerOffset,
                });

                // 2. Bottle stays straight during section 2 and moves into Customize Section (3)
                pinAndAnimate({
                    trigger: ".section-intro",
                    endTrigger: ".timeline-section",
                    pin: ".hero-bottle-wrapper",
                    animations: [
                        { target: ".hero-bottle", vars: { rotate: 0, scale: 1, y: "10%", duration: 1 }, position: 0 }
                    ],
                    markers: false,
                    headerOffset,
                });

                // 3. Bottle shifts left during Section 3 (Customize)
                pinAndAnimate({
                    trigger: ".timeline-section",
                    endTrigger: ".timeline-section-2",
                    pin: ".hero-bottle-wrapper",
                    animations: [
                        { target: ".hero-bottle", vars: { rotate: 0, scale: 1, y: "10%", x: "5%", duration: 1, ease: "power2.inOut" }, position: 2 },
                    ],
                    markers: false,
                    headerOffset,
                });
            },

            // Mobile scroll animations
            "(max-width: 768px)": function () {
                gsap.to(".hero-bottle-wrapper", {
                    opacity: 1,
                    duration: 1,
                    delay: 0.5,
                });
                
                pinAndAnimate({
                    trigger: ".hero",
                    endTrigger: ".section-intro",
                    pin: ".hero-bottle-wrapper",
                    animations: [
                        { target: ".hero-bottle", vars: { rotate: 0, scale: 1 } },
                    ],
                    headerOffset,
                });

                pinAndAnimate({
                    trigger: ".section-intro",
                    endTrigger: ".timeline-section",
                    pin: ".hero-bottle-wrapper",
                    animations: [
                        { target: ".hero-bottle", vars: { rotate: 0, scale: 1, y: "10%", duration: 1 }, position: 0 }
                    ],
                    markers: false,
                    headerOffset,
                });
                
                pinAndAnimate({
                    trigger: ".timeline-section",
                    endTrigger: ".timeline-section-2",
                    pin: ".hero-bottle-wrapper",
                    animations: [
                        { target: ".hero-bottle", vars: { rotate: 0, scale: 1, y: "10%", duration: 1, ease: "power2.inOut" }, position: 2 },
                        { target: ".hero-bottle-wrapper", vars: { x: "0%", duration: 1, ease: "power2.inOut" }, position: 2 },
                    ],
                    markers: false,
                    headerOffset,
                });
            },
        });
    }

    setupScrollAnimations();
    
    const cards = document.querySelectorAll('.gallery-card');
    
    // Store original states
    const states = Array.from(cards).map(card => ({
        className: card.className,
        style: card.getAttribute('style')
    }));
    
    let currentIndex = 0;
    
    // Cycle every 3 seconds
    setInterval(() => {
        // Move backwards through the array to make it rotate smoothly right-to-left
        currentIndex = (currentIndex - 1 + states.length) % states.length;
        
        cards.forEach((card, i) => {
            const stateIndex = (i + currentIndex) % states.length;
            card.className = states[stateIndex].className;
            card.setAttribute('style', states[stateIndex].style);
        });
    }, 3000);
});
